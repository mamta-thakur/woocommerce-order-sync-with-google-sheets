jQuery(document).ready(function($) {
    // When the "View More Info" button is clicked
    $('.view-more-info').click(function() {
        // Toggle the display of the shipping description popup
        $(this).siblings('.shipping-description-popup').toggle();
    });
});
