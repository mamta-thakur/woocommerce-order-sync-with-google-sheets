<?php
// A fish with closed mouth, never gets caught.
